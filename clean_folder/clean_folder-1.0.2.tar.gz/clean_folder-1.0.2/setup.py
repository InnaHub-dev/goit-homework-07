from setuptools import setup, find_namespace_packages

setup(
      name='clean_folder',
      version='1.0.2',
      description='Sorting files',
      url='https://github.com/InnaHub-dev/goit-homework-07.git',
      readme='README.md',
      author='Inna Hubenko',
      author_email='learneng.ge@gmail.com',
      license='MIT',
      packages=find_namespace_packages(),
      include_package_data=True,
      entry_points={'console_scripts':['clean-folder = clean_folder.sort:main']},
)
