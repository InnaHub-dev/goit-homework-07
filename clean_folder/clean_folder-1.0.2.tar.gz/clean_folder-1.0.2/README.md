# Clean-folder

Console app that sorts folder's content. Could be called from the console by command clean-folder. You need to pass a path to the folder you want to sort as a first argument in command line. 